# OIBSIP
Oasis Infobyte Internship.
Task 1
Landing page of E-Commerce website "@TrEndSoCiEtY" using html and css.

